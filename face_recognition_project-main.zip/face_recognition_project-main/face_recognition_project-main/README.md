# face_recognition_project
by Chinmay gowda bs from Mit Mysore